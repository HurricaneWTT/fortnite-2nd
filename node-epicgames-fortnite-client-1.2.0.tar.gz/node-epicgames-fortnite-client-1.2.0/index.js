module.exports = {
	Namespace: 'fn',
    Client: require('./src/Client')
};